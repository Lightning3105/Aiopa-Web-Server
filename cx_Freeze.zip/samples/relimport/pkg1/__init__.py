# -*- coding: utf-8 -*-

import sys

sys.stdout.write('importing pkg1\n')

from . import sub1
from . import pkg2
